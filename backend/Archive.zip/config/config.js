const config = {};

config.name = 'Elandy';
config.pw = 'React123';

module.exports = config;
